package vue;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

/**
 *
 * @author Cédric BOUHOURS
 */
public class FenetreAccueil  {
    
    @FXML
    private Button button;

    @FXML
    private VBox vBox;

    @FXML
    void handleButtonAction(ActionEvent event) {
        try {
            vBox.getChildren().add(new MonUserControl());
        } catch (IOException ex) {
            Logger.getLogger(FenetreAccueil.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    
}
