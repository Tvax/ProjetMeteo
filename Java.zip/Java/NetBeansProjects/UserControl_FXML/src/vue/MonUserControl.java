package vue;

import java.io.IOException;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 *
 * @author Cédric BOUHOURS
 */
public class MonUserControl extends HBox {

    @FXML
    private Label label;
        public String getLabel() {return label.getText();}
        public void setLabel(String value) {label.setText(value);}
        public StringProperty labelProperty() {return label.textProperty();}

    public MonUserControl() throws IOException {
        FXMLLoader leLoader = new FXMLLoader(getClass().getResource("/fxml/MonUserControl.fxml"));
        leLoader.setController(this);
        leLoader.setRoot(this);
        leLoader.load();
    }

    @FXML
    private void clicSurCoucou() {
        label.setText("Clic sur le bouton !!");
    }   
}
