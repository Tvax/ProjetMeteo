package launcher;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Cédric BOUHOURS
 */
public class Main extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {       
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/fxml/FenetreAccueil.fxml")));
        stage.setScene(scene);
        stage.show();
    }
    
}
