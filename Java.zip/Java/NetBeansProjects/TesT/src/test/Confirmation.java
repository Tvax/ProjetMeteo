/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

/**
 *
 * @author dekarupovi
 */
class Confirmation {
    @FXML
    private Button oui,non;
    @FXML
    private void NonButtonAction(ActionEvent event) {
        non.setText("Hello !");
    }
    @FXML
    private void OuiButtonAction(ActionEvent event) {
        oui.setText("Hello World!");
    }
}
